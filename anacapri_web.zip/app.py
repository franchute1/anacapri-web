
from flask import Flask, render_template, request, redirect
import sqlite3
import urllib.parse

app = Flask(__name__)

def init_db():
    with sqlite3.connect("pedidos.db") as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS pedidos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT,
                direccion TEXT,
                litros INTEGER,
                dia TEXT,
                hora TEXT
            )
        ''')

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/pedido", methods=["GET", "POST"])
def pedido():
    if request.method == "POST":
        nombre = request.form["nombre"]
        direccion = request.form["direccion"]
        litros = request.form["litros"]
        dia = request.form["dia"]
        hora = request.form["hora"]

        with sqlite3.connect("pedidos.db") as conn:
            conn.execute("INSERT INTO pedidos (nombre, direccion, litros, dia, hora) VALUES (?, ?, ?, ?, ?)",
                         (nombre, direccion, litros, dia, hora))

        mensaje = f"Hola, soy {nombre}. Quiero pedir {litros} litros de gasoil para {dia} a las {hora}. Dirección: {direccion}"
        mensaje_encoded = urllib.parse.quote(mensaje)
        whatsapp_url = f"https://wa.me/5491157375754?text={mensaje_encoded}"

        return redirect(whatsapp_url)

    return render_template("pedido.html")

@app.route("/gracias")
def gracias():
    return render_template("gracias.html")

@app.context_processor
def inject_nav():
    return dict(nav_links={"Inicio": "/", "Pedir Gasoil": "/pedido"})

if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=5000)
